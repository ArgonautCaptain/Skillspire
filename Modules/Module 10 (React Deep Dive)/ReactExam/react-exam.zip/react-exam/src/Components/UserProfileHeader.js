import react from 'react';

const UserProfileHeader = () => {
  return (
    <div className="user-profile-header">
      <h1>Part 1 & 2</h1>
    </div>
  );
};

export default UserProfileHeader;
