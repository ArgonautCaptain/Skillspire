import react from 'react';

const HomePage = () => {
  return (
    <div className="home-page">
      <h1>Jason Updegraff</h1>
    </div>
  );
};

export default HomePage;
