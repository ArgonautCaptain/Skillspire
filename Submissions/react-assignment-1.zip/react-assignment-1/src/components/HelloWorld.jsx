import React from 'react';

const HelloWorld = () => {
    return <h1>Hello World</h1>;
};

export default HelloWorld;