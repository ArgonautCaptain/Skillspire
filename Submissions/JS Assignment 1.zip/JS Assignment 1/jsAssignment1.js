console.log("Hello World");
console.log("Name: Jason Updegraff");
console.log("Favorite Color: Blue");
console.log(1+1);

var stringOne = "Jason";
var stringTwo = "Updegraff";

console.log(stringOne + " " + stringTwo);

for (var i = 1; i <= 10; i++) {
    console.log(i);
}

for (var i = 0; i < 5; i++) {
    console.log("Skillspire");
}

for (var i = 1; i <= 10; i++) {
  console.log(2 * i);
}

for (var i = 1; i <= 10; i++) {
  console.log(2 * i);
}

for (var i = 1; i <= 10; i++) {
  console.log(2 * i - 1);
}

for (var i = 1; i <= 10; i++) {
  if (i % 2 == 0) {
    console.log("FIZZ");
  }
  else {
    console.log("BUZZ");
  }
}