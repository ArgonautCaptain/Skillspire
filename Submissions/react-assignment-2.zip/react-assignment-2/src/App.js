import logo from './logo.svg';
import './App.css';
import PersonalInfo from './components/PersonalInfo';

function App() {
  return (
    <div className="App">
      <PersonalInfo />
    </div>
  );
}

export default App;
