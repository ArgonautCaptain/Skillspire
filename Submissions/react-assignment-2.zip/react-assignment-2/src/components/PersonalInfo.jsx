import React from 'react';

const PersonalInfo = () => {
    return <div>
        <h1>First Name: Jason</h1>
        <h1>Last Name: Updegraff</h1>
        <h1>Favorite Food: Sushi</h1>
        <h1>Favorite Vacation Destination: Japan</h1>
    </div>;
};

export default PersonalInfo;