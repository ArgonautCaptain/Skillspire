import logo from './logo.svg';
import './App.css';
import ConditionRenderer from './components/ConditionRenderer';

function App() {
  return (
    <div className="App">
      <ConditionRenderer />
    </div>
  );
}

export default App;
