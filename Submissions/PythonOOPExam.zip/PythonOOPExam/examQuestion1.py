fahrenheit = float(input("Enter the current temperature in Fahrenheit: "))

celsius = (fahrenheit - 32) * 5/9

print(f"Temperature in Celsius: {celsius:.1f}")