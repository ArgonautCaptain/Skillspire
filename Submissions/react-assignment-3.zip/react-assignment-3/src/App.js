import logo from './logo.svg';
import './App.css';
import ElementRenderer from './components/ElementRenderer';

function App() {
  return (
    <div className="App">
      <ElementRenderer />
    </div>
  );
}

export default App;
