print("Formula: 3x + 5y = ?")
x = int(input("Enter the value of x: "))
y = int(input("Enter the value of y: "))
result = 3 * x + 5 * y
print(f"The result of the formula 3x + 5y is: {result}")