import React from 'react';

function DisplayName() {
  return (
    <div>
      <h1>Jason Updegraff</h1>
    </div>
  );
}

export default DisplayName; 