import logo from './logo.svg';
import './App.css';
import ListRenderer from './components/ListRenderer';

function App() {
  return (
    <div className="App">
      <ListRenderer />
    </div>
  );
}

export default App;
