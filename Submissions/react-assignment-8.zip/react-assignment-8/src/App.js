import logo from './logo.svg';
import './App.css';
import EventHandler from './components/EventHandler';

function App() {
  return (
    <div className="App">
      <EventHandler />
    </div>
  );
}

export default App;
